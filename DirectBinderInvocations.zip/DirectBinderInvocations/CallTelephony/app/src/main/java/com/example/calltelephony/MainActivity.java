package com.example.calltelephony;


import android.content.Context;
import android.os.Bundle;
import android.os.RemoteException;
import android.telephony.TelephonyManager;
import android.content.pm.PackageManager;
import android.Manifest;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;

import com.example.calltelephony.databinding.ActivityMainBinding;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import android.os.IBinder;
import android.os.Parcel;
public class MainActivity extends AppCompatActivity {

    private String transactTelephonyService() {
        String result = "";
        Method getService = null;
        IBinder binder = null;
        Parcel data = null;
        Parcel reply = null;

        try {
            getService = Class.forName("android.os.ServiceManager").getMethod("getService", String.class);
            binder = (IBinder) getService.invoke(null, "phone");

            data = Parcel.obtain();
            reply = Parcel.obtain();

            data.writeInterfaceToken("com.android.internal.telephony.ITelephony");
            data.writeString("12345678"); // add the phone number argument

            // Binder transact
            binder.transact(1, data, reply, 0);

            reply.readException();
            result = reply.readString(); // will be empty, no return value*/

        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (InvocationTargetException e) {
            throw new RuntimeException(e);
        } catch (RemoteException e) {
            throw new RuntimeException(e);
        } finally {
            data.recycle();
            reply.recycle();
        }

        return "test";
    }

    // Used to load the 'calltelephony' library on application startup.
    static {
        System.loadLibrary("calltelephony");
    }

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Example of a call to a native method
        TextView tv = binding.sampleText;
        tv.setText(transactTelephonyService());
    }


    //public native String transactTelephonyServiceNative();
}