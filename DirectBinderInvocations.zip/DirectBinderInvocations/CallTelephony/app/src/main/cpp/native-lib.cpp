#include <jni.h>
#include <string>
#include <fstream>
#include <dlfcn.h>
#include <cstdlib>
#include <vector>
#include <map>
#include <sstream>
#include <android/log.h>

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_calltelephony_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {
    std::string hello = "Hello from C++";
    return env->NewStringUTF(hello.c_str());
}

// Native dial call
/*
extern "C" JNIEXPORT jstring JNICALL
Java_com_example_calltelephony_MainActivity_transactTelephonyServiceNative(JNIEnv* env, jobject this) {
    std::string hello = "Hello from C++";

    // Parcel objects setup
    jclass parcelClass = env->FindClass("android/os/Parcel");
    jmethodID obtainMethodID = env->GetStaticMethodID(parcelClass, "obtain", "()Landroid/os/Parcel;");

    jobject dataParcel = env->CallStaticObjectMethod(parcelClass, obtainMethodID);
    jobject replyParcel = env->CallStaticObjectMethod(parcelClass, obtainMethodID);

    jmethodID writeInterfaceTokenMethodID = env->GetMethodID(parcelClass, "writeInterfaceToken", "(Ljava/lang/String;)V");
    jstring interfaceToken = env->NewStringUTF("com.android.internal.telephony.ITelephony");
    env->CallVoidMethod(dataParcel, writeInterfaceTokenMethodID, interfaceToken);
    jmethodID writeStringMethodID = env->GetMethodID(parcelClass, "writeString", "(Ljava/lang/String;)V");

    jstring phoneNumber = env->NewStringUTF("12345678");
    env->CallVoidMethod(dataParcel, writeStringMethodID, phoneNumber);

    // Binder calling
    jclass serviceManagerClass = env->FindClass("android/os/ServiceManager");
    jmethodID getServiceMethodID = env->GetStaticMethodID(serviceManagerClass, "getService", "(Ljava/lang/String;)Landroid/os/IBinder;");

    jstring serviceName = env->NewStringUTF("phone");
    jobject binder = env->CallStaticObjectMethod(serviceManagerClass, getServiceMethodID, serviceName);

    // Make the transaction
    jclass iBinderClass = env->FindClass("android/os/IBinder");
    jmethodID transactMethodID = env->GetMethodID(iBinderClass, "transact", "(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z");
    env->CallBooleanMethod(binder, transactMethodID, 1, dataParcel, replyParcel, 0);

    return env->NewStringUTF(hello.c_str());
}*/